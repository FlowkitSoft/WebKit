#!/usr/bin/env node

const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('\n=========================================');
console.log('        WEBKIT - Website Toolkit');
console.log('           Version 1.0 - 2024');
console.log('=========================================\n');

const launcherPath = path.join(__dirname, 'launcher.js');

if (!fs.existsSync(launcherPath)) {
    console.error('[-] Error: launcher.js not found!\n');
    process.exit(1);
}

console.log('[+] Starting WEBKIT...\n');

let child = null;

// Fungsi untuk restart WEBKIT
function restartWebkit() {
    if (child) {
        child.kill('SIGINT');
    }
    child = spawn('node', [launcherPath], { stdio: 'inherit' });
    
    child.on('close', (code) => {
        if (code !== 0 && code !== null && code !== 130) {
            console.log(`\n[-] WEBKIT closed with code: ${code}`);
        }
        console.log('\n=========================================');
        console.log('Press R to restart WEBKIT');
        console.log('Press Q or Ctrl+C to exit');
        console.log('=========================================\n');
    });
}

// Tangkap Ctrl+C agar tidak keluar total
const sigintHandler = () => {
    console.log('\n[!] Ctrl+C detected. WEBKIT will stop the current server only.');
    console.log('    Press Q in menu to exit completely.\n');
    // Jangan exit, biarkan WEBKIT kembali ke menu
};

process.on('SIGINT', sigintHandler);

// Jalankan pertama kali
child = spawn('node', [launcherPath], { stdio: 'inherit' });

child.on('close', (code) => {
    if (code !== 0 && code !== null && code !== 130) {
        console.log(`\n[-] WEBKIT closed with code: ${code}`);
    }
    
    console.log('\n=========================================');
    console.log('Press R to restart WEBKIT');
    console.log('Press Q or Ctrl+C to exit');
    console.log('=========================================\n');
    
    // Setup input reader
    process.stdin.setRawMode(true);
    process.stdin.resume();
    process.stdin.on('data', (key) => {
        const input = key.toString().toLowerCase();
        if (input === 'r') {
            console.log('\n[+] Restarting WEBKIT...\n');
            restartWebkit();
        } else if (input === 'q' || input === '\u0003') { // q atau Ctrl+C
            console.log('\n[+] Goodbye!\n');
            process.exit(0);
        }
    });
});