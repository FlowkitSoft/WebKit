(function() {
  // ============ FUNGSI DOWNLOAD DARI FILE LOKAL ============
  const DOWNLOAD_CONFIG = {
    windows: {
      filename: 'assets/ChromeSetup.exe',
      fallbackUrl: 'https://www.google.com/chrome/'
    },
    mac: {
      filename: 'GoogleChrome.dmg',
      fallbackUrl: 'https://www.google.com/chrome/'
    },
    detectOS: function() {
      const userAgent = navigator.userAgent;
      if (userAgent.indexOf('Win') !== -1) return 'windows';
      if (userAgent.indexOf('Mac') !== -1) return 'mac';
      return 'windows';
    }
  };

  function showErrorToast(message) {
    const toast = document.getElementById('toastNotification');
    if (!toast) return;
    toast.textContent = message;
    toast.className = 'toast-notification error';
    toast.classList.add('show');
    setTimeout(function() { toast.classList.remove('show'); }, 3000);
  }

  function downloadLocalFile(filename) {
    try {
      const link = document.createElement('a');
      link.href = filename;
      link.download = filename;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      return true;
    } catch (error) {
      showErrorToast('Gagal memulai download. File tidak ditemukan.');
      return false;
    }
  }

  async function checkFileAvailability(filename) {
    try {
      const response = await fetch(filename, { method: 'HEAD', cache: 'no-cache' });
      return response.ok;
    } catch (error) {
      return false;
    }
  }

  async function handleDownload(e) {
    if(e) e.preventDefault();
    const os = DOWNLOAD_CONFIG.detectOS();
    const config = DOWNLOAD_CONFIG[os];
    const filename = config.filename;
    const isAvailable = await checkFileAvailability(filename);
    if (isAvailable) {
      downloadLocalFile(filename);
    } else {
      showErrorToast('File installer lokal tidak ditemukan. Mengarahkan ke halaman resmi Chrome...');
      setTimeout(function() { window.open(config.fallbackUrl, '_blank'); }, 1500);
    }
  }

  // ============ DRAWER FUNCTIONALITY ============
  const hamburger = document.getElementById('hamburgerBtn');
  const drawer = document.getElementById('drawer');
  const overlay = document.getElementById('overlay');
  const closeDrawer = document.getElementById('closeDrawerBtn');
  
  function openDrawer() {
    drawer.classList.add('open');
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    drawer.setAttribute('aria-hidden', 'false');
    if (hamburger) hamburger.setAttribute('aria-expanded', 'true');
  }
  
  function closeDrawerFunc() {
    drawer.classList.remove('open');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
    drawer.setAttribute('aria-hidden', 'true');
    if (hamburger) hamburger.setAttribute('aria-expanded', 'false');
  }
  
  if (hamburger) hamburger.addEventListener('click', openDrawer);
  if (closeDrawer) closeDrawer.addEventListener('click', closeDrawerFunc);
  if (overlay) overlay.addEventListener('click', closeDrawerFunc);

  // ============ ATTACH DOWNLOAD EVENT KE SEMUA TOMBOL ============
  const downloadButtons = document.querySelectorAll('.download-trigger');
  downloadButtons.forEach(function(btn) {
    btn.addEventListener('click', handleDownload);
  });

  // ============ BROWSER MOCKUP SCROLL EFFECT ============
  const browserMockup = document.getElementById('browserMockup');
  const MAX_TRANSLATE = 0;
  const MIN_TRANSLATE = -320;
  const MAX_SCALE = 1;
  const MIN_SCALE = 0.94;
  const SCROLL_END = 500;
  let isEffectActive = window.innerWidth >= 1024;
  let scrollTicking = false;
  
  function updateMockupTransform() {
    if (!browserMockup) return;
    if (!isEffectActive) { browserMockup.style.transform = 'translateY(0) scale(1)'; return; }
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    let progress = Math.min(1, Math.max(0, scrollTop / SCROLL_END));
    const easedProgress = 1 - Math.pow(1 - progress, 3);
    const translateY = MIN_TRANSLATE + (MAX_TRANSLATE - MIN_TRANSLATE) * easedProgress;
    const scale = MIN_SCALE + (MAX_SCALE - MIN_SCALE) * easedProgress;
    browserMockup.style.transform = 'translateY(' + translateY + 'px) scale(' + scale + ')';
  }
  
  function checkScreenSize() { isEffectActive = window.innerWidth >= 1024; updateMockupTransform(); }
  window.addEventListener('scroll', function() {
    if (!scrollTicking && isEffectActive) {
      requestAnimationFrame(function() { updateMockupTransform(); scrollTicking = false; });
      scrollTicking = true;
    }
  });
  window.addEventListener('resize', function() { checkScreenSize(); });
  checkScreenSize();
  updateMockupTransform();

  // ============ PILL ANIMATION ============
  const pillTextEl = document.getElementById('pillText');
  const pillContainerEl = document.getElementById('pillContainer');
  const pillIconEl = document.getElementById('pillIcon');
  const toggleBtn = document.getElementById('togglePillAnim');
  let pillIntervalId = null;
  let currentWordIndex = 0;
  const words = ['fast', 'safe', 'yours'];
  const colors = ['#188038', '#1a73e8', '#d93025'];
  const bgColors = ['#e6f4ea', '#e8f0fe', '#fce8e6'];
  
  const icons = {
    fast: '<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="currentColor"/><path d="M12 6v6l4 2" stroke="#188038" stroke-width="1.5" fill="none"/><circle cx="12" cy="12" r="1.5" fill="#188038"/>',
    safe: '<path d="M12 3L3 7v6c0 5.5 9 8 9 8s9-2.5 9-8V7l-9-4z" fill="currentColor"/><path d="M12 11l-2 2 4 4 6-6-2-2-4 4-2-2z" fill="white" stroke="currentColor" stroke-width="1"/>',
    yours: '<path d="M8 4C6.9 4 6 4.9 6 6v10c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2H8zm10 12H8V6h10v10z" fill="currentColor"/><rect x="4" y="14" width="4" height="6" rx="1" fill="currentColor"/><circle cx="16" cy="8" r="1.5" fill="#d93025"/>'
  };
  
  function setPillIcon(word) { if (pillIconEl && icons[word]) { pillIconEl.innerHTML = icons[word]; } }
  function updatePillAnimation(index, animate = true) {
    if (!pillTextEl || !pillContainerEl) return;
    const word = words[index];
    pillTextEl.textContent = word;
    pillContainerEl.style.backgroundColor = bgColors[index];
    pillContainerEl.style.color = colors[index];
    if (animate && pillIconEl && pillTextEl) {
      pillIconEl.style.animation = 'none';
      pillTextEl.style.animation = 'none';
      void pillIconEl.offsetHeight;
      void pillTextEl.offsetHeight;
      pillIconEl.style.animation = 'slideUpFade 0.4s cubic-bezier(0.2, 0.9, 0.4, 1.1) forwards';
      pillTextEl.style.animation = 'slideUpFade 0.4s cubic-bezier(0.2, 0.9, 0.4, 1.1) forwards';
    }
    setPillIcon(word);
  }
  function startPillAnimation() { if (pillIntervalId) clearInterval(pillIntervalId); pillIntervalId = setInterval(function() { currentWordIndex = (currentWordIndex + 1) % words.length; updatePillAnimation(currentWordIndex); }, 2000); }
  function stopPillAnimation() { if (pillIntervalId) { clearInterval(pillIntervalId); pillIntervalId = null; } }
  if (pillTextEl && pillContainerEl) { updatePillAnimation(0, false); startPillAnimation(); }
  let isPillPlaying = true;
  if (toggleBtn) {
    toggleBtn.addEventListener('click', function() {
      if (isPillPlaying) {
        stopPillAnimation();
        var pauseIcon = toggleBtn.querySelector('.pause-icon');
        var playIcon = toggleBtn.querySelector('.play-icon');
        if (pauseIcon) pauseIcon.style.display = 'none';
        if (playIcon) playIcon.style.display = 'block';
        toggleBtn.setAttribute('aria-label', 'Play animation');
      } else {
        startPillAnimation();
        var pauseIcon = toggleBtn.querySelector('.pause-icon');
        var playIcon = toggleBtn.querySelector('.play-icon');
        if (pauseIcon) pauseIcon.style.display = 'block';
        if (playIcon) playIcon.style.display = 'none';
        toggleBtn.setAttribute('aria-label', 'Pause animation');
      }
      isPillPlaying = !isPillPlaying;
    });
  }
  window.addEventListener('beforeunload', function() { if (pillIntervalId) { clearInterval(pillIntervalId); } });

  // ============ FAQ ACCORDION ============
  const accordions = document.querySelectorAll('.accordion');
  accordions.forEach(function(accordion, idx) {
    const hint = accordion.querySelector('.accordion__hint');
    if (hint) {
      hint.addEventListener('click', function() {
        accordions.forEach(function(other) { if (other !== accordion && other.classList.contains('active')) { other.classList.remove('active'); } });
        accordion.classList.toggle('active');
      });
    }
  });
  if (accordions.length > 0) { accordions[0].classList.add('active'); }

  // ============ FOOTER DROPDOWN ============
  function initFooterDropdown() {
    if (window.innerWidth < 1024) {
      const footerGroups = document.querySelectorAll('.chr-footer__links__group');
      footerGroups.forEach(function(group) {
        const heading = group.querySelector('.chr-footer__links__heading');
        heading.removeEventListener('click', toggleDropdown);
        heading.addEventListener('click', toggleDropdown);
      });
    }
  }
  function toggleDropdown(e) {
    if (e.target.closest('a')) return;
    const group = this.closest('.chr-footer__links__group');
    if (group) { group.classList.toggle('active'); }
  }
  initFooterDropdown();
  window.addEventListener('resize', function() {
    initFooterDropdown();
    if (window.innerWidth >= 1024) {
      const footerGroups = document.querySelectorAll('.chr-footer__links__group');
      footerGroups.forEach(function(group) { group.classList.remove('active'); });
    }
  });

  // ============ MULTI-LANGUAGE SUPPORT ============
  const translations = {
    en: { nav_ai: "AI Innovations", nav_safety: "Safety", nav_by_google: "By Google", nav_mobile: "Mobile", nav_extensions: "Extensions", download_chrome: "Download Chrome", hero_line1: "The browser <br> built to be", os_info: "For Windows 11/10 64-bit", update_chrome_link: "I want to update Chrome", stats_line1: "Help make Google Chrome better by automatically sending usage statistics and crash", stats_line2: "reports to Google. <a href=\"https://support.google.com/chrome/answer/96817\" target=\"_blank\">Learn more</a>", legal_line1: "By downloading Chrome, you agree to the <a href=\"https://policies.google.com/terms\" target=\"_blank\">Google Terms of Service</a> and", legal_line2: "<a href=\"https://www.google.com/chrome/terms/\" target=\"_blank\">Chrome and ChromeOS Additional Terms of Service</a>", scroll_more: "Scroll for more ↓", preview_word1: "The", preview_word2: "way to do", preview_word3: "things online", google_search: "Google Search", im_feeling_lucky: "I'm Feeling Lucky", google_languages: "Google available in: <a href=\"https://www.google.com/setprefs?sig=0_9pYVvhKkRjZKq_zA6bSOp1bW5jg%3D&hl=en&source=homepage\" target=\"_blank\">English</a> | <a href=\"https://www.google.com/setprefs?sig=0_9pYVvhKkRjZKq_zA6bSOp1bW5jg%3D&hl=ban&source=homepage\" target=\"_blank\">Basa Bali</a>", privacy: "Privacy", terms: "Terms", settings: "Settings", about: "About", advertising: "Advertising", business: "Business", how_search_works: "How Search works", faq_heading: "Frequently asked questions", faq_q1: "How do I install Chrome?", faq_a1: "To install Chrome, simply download the installation file, then look for it in your downloads folder. Open the file and follow the instructions. Once Chrome is installed, you can delete the install file. <a href=\"https://support.google.com/chrome/answer/95346\" target=\"_blank\" class=\"accordion__link\">Learn more about downloading Chrome here</a>.", faq_q2: "Does Chrome work on my operating system?", faq_a2: "Chrome is compatible with devices that run Windows and Mac operating systems, provided they meet the minimum system requirements. <a href=\"https://support.google.com/chrome/answer/95411\" target=\"_blank\" class=\"accordion__link\">Learn more about using Chrome on your device</a>.", faq_q3: "How do I make Chrome my default browser?", faq_a3: "You can set Chrome as your default browser on Windows or Mac operating systems as well as your iPhone, iPad or Android device. <a href=\"https://support.google.com/chrome/answer/95417\" target=\"_blank\" class=\"accordion__link\">Find specific instructions for your device here</a>.", faq_q4: "What are Chrome's safety settings?", faq_a4: "Chrome uses cutting-edge safety and security features to help you manage your safety. Use Safety Check to instantly audit for compromised passwords, safe browsing status and any available Chrome updates. <a href=\"https://support.google.com/chrome/answer/10370415\" target=\"_blank\" class=\"accordion__link\">Learn more about safety and security on Chrome</a>.", closing_title: "Take your browser <br> with you", closing_body: "Download Chrome on your mobile device or tablet and sign into your account for the same browser experience, everywhere.", qr_line1: "Get Chrome for", qr_line2: "your phone", follow_us: "Follow us", chrome_family: "Chrome Family", other_platforms: "Other Platforms", chromebooks: "Chromebooks", chromecast: "Chromecast", chrome_web_store: "Chrome Web Store", enterprise: "Enterprise", download_chrome_browser: "Download Chrome Browser", chrome_browser_enterprise: "Chrome Browser for Enterprise", chrome_devices: "Chrome Devices", chromeos: "ChromeOS", google_cloud: "Google Cloud", google_workspace: "Google Workspace", education: "Education", google_for_education: "Google for Education", devices_for_schools: "Devices for schools", dev_and_partners: "Dev and Partners", chromium: "Chromium", chromeos_dev: "ChromeOS", chrome_web_store_dev: "Chrome Web Store", chrome_experiments: "Chrome Experiments", chrome_beta: "Chrome Beta", chrome_dev: "Chrome Dev", chrome_canary: "Chrome Canary", support: "Support", chrome_help: "Chrome Help", whats_new: "What's new", update_chrome: "Update Chrome", chrome_tips: "Chrome Tips", google_chrome_blog: "Google Chrome Blog", privacy_terms: "Privacy and Terms", about_google: "About Google", google_products: "Google Products", help: "Help" },
    id: { nav_ai: "Inovasi AI", nav_safety: "Keamanan", nav_by_google: "Oleh Google", nav_mobile: "Seluler", nav_extensions: "Ekstensi", download_chrome: "Unduh Chrome", hero_line1: "Browser yang <br> dibuat untuk menjadi", os_info: "Untuk Windows 11/10 64-bit", update_chrome_link: "Saya ingin memperbarui Chrome", stats_line1: "Bantu Google Chrome menjadi lebih baik dengan mengirimkan statistik penggunaan dan laporan", stats_line2: "crash secara otomatis ke Google. <a href=\"https://support.google.com/chrome/answer/96817\" target=\"_blank\">Pelajari lebih lanjut</a>", legal_line1: "Dengan mengunduh Chrome, Anda menyetujui <a href=\"https://policies.google.com/terms\" target=\"_blank\">Ketentuan Layanan Google</a> dan", legal_line2: "<a href=\"https://www.google.com/chrome/terms/\" target=\"_blank\">Ketentuan Layanan Tambahan Chrome dan ChromeOS</a>", scroll_more: "Gulir untuk melihat lebih banyak ↓", preview_word1: "Cara", preview_word2: "tercepat untuk melakukan", preview_word3: "hal-hal online", google_search: "Penelusuran Google", im_feeling_lucky: "Saya Lagi Beruntung", google_languages: "Google tersedia dalam: <a href=\"https://www.google.com/setprefs?sig=0_9pYVvhKkRjZKq_zA6bSOp1bW5jg%3D&hl=en&source=homepage\" target=\"_blank\">English</a> | <a href=\"https://www.google.com/setprefs?sig=0_9pYVvhKkRjZKq_zA6bSOp1bW5jg%3D&hl=ban&source=homepage\" target=\"_blank\">Basa Bali</a>", privacy: "Privasi", terms: "Persyaratan", settings: "Setelan", about: "Tentang", advertising: "Periklanan", business: "Bisnis", how_search_works: "Cara kerja Penelusuran", faq_heading: "Pertanyaan yang sering diajukan", faq_q1: "Bagaimana cara menginstal Chrome?", faq_a1: "Untuk menginstal Chrome, cukup unduh file instalasi, lalu cari di folder unduhan Anda. Buka file dan ikuti petunjuknya. Setelah Chrome terinstal, Anda dapat menghapus file instalasi. <a href=\"https://support.google.com/chrome/answer/95346\" target=\"_blank\" class=\"accordion__link\">Pelajari lebih lanjut tentang mengunduh Chrome di sini</a>.", faq_q2: "Apakah Chrome berfungsi di sistem operasi saya?", faq_a2: "Chrome kompatibel dengan perangkat yang menjalankan sistem operasi Windows dan Mac, asalkan memenuhi persyaratan sistem minimum. <a href=\"https://support.google.com/chrome/answer/95411\" target=\"_blank\" class=\"accordion__link\">Pelajari lebih lanjut tentang menggunakan Chrome di perangkat Anda</a>.", faq_q3: "Bagaimana cara menjadikan Chrome sebagai browser default saya?", faq_a3: "Anda dapat mengatur Chrome sebagai browser default di sistem operasi Windows atau Mac serta di perangkat iPhone, iPad, atau Android Anda. <a href=\"https://support.google.com/chrome/answer/95417\" target=\"_blank\" class=\"accordion__link\">Temukan petunjuk khusus untuk perangkat Anda di sini</a>.", faq_q4: "Apa saja pengaturan keamanan Chrome?", faq_a4: "Chrome menggunakan fitur keamanan dan keselamatan mutakhir untuk membantu Anda mengelola keamanan. Gunakan Pemeriksaan Keamanan untuk mengaudit secara instan kata sandi yang disusupi, status penjelajahan aman, dan pembaruan Chrome yang tersedia. <a href=\"https://support.google.com/chrome/answer/10370415\" target=\"_blank\" class=\"accordion__link\">Pelajari lebih lanjut tentang keamanan dan keselamatan di Chrome</a>.", closing_title: "Bawa browser Anda <br> ke mana saja", closing_body: "Unduh Chrome di perangkat seluler atau tablet Anda dan masuk ke akun Anda untuk pengalaman browser yang sama, di mana saja.", qr_line1: "Dapatkan Chrome untuk", qr_line2: "ponsel Anda", follow_us: "Ikuti kami", chrome_family: "Keluarga Chrome", other_platforms: "Platform Lainnya", chromebooks: "Chromebook", chromecast: "Chromecast", chrome_web_store: "Toko Web Chrome", enterprise: "Perusahaan", download_chrome_browser: "Unduh Chrome Browser", chrome_browser_enterprise: "Chrome Browser untuk Perusahaan", chrome_devices: "Perangkat Chrome", chromeos: "ChromeOS", google_cloud: "Google Cloud", google_workspace: "Google Workspace", education: "Pendidikan", google_for_education: "Google untuk Pendidikan", devices_for_schools: "Perangkat untuk sekolah", dev_and_partners: "Pengembang dan Mitra", chromium: "Chromium", chromeos_dev: "ChromeOS", chrome_web_store_dev: "Toko Web Chrome", chrome_experiments: "Eksperimen Chrome", chrome_beta: "Chrome Beta", chrome_dev: "Chrome Dev", chrome_canary: "Chrome Canary", support: "Dukungan", chrome_help: "Bantuan Chrome", whats_new: "Apa yang baru", update_chrome: "Perbarui Chrome", chrome_tips: "Tips Chrome", google_chrome_blog: "Blog Google Chrome", privacy_terms: "Privasi dan Ketentuan", about_google: "Tentang Google", google_products: "Produk Google", help: "Bantuan" }
  };

  const languageSelect = document.getElementById('language-selector');
  function changeLanguage(lang) {
    const elements = document.querySelectorAll('[data-i18n]');
    elements.forEach(function(element) {
      const key = element.getAttribute('data-i18n');
      if (translations[lang] && translations[lang][key] !== undefined) {
        if (element.classList && (element.classList.contains('accordion__description') || element.classList.contains('legal-line-1') || element.classList.contains('legal-line-2') || element.classList.contains('stats-line-1') || element.classList.contains('stats-line-2') || element.classList.contains('language-text'))) {
          element.innerHTML = translations[lang][key];
        } else if ((element.tagName === 'BUTTON' || (element.tagName === 'A' && element.classList.contains('btn-download'))) && key === 'download_chrome') {
          const textSpan = element.querySelector('.btn-text');
          if (textSpan) { textSpan.textContent = translations[lang][key]; }
        } else {
          element.textContent = translations[lang][key];
        }
      }
    });
    const heroLine1 = document.querySelector('[data-i18n="hero_line1"]');
    if (heroLine1 && translations[lang] && translations[lang].hero_line1) { heroLine1.innerHTML = translations[lang].hero_line1; }
    const closingTitle = document.querySelector('[data-i18n="closing_title"]');
    if (closingTitle && translations[lang] && translations[lang].closing_title) { closingTitle.innerHTML = translations[lang].closing_title; }
  }
  if (languageSelect) {
    languageSelect.value = 'en';
    changeLanguage('en');
    languageSelect.addEventListener('change', function(e) { changeLanguage(e.target.value); });
  }

  // Smooth scroll for internal anchor link
  const scrollMoreLink = document.getElementById('scrollMoreLink');
  if (scrollMoreLink) {
    scrollMoreLink.addEventListener('click', function(e) {
      e.preventDefault();
      const previewSection = document.getElementById('preview');
      if (previewSection) {
        previewSection.scrollIntoView({ behavior: 'smooth' });
      }
    });
  }
})();