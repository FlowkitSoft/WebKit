<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Google Chrome - Fast, Secure Browser</title>
  <!-- Favicon Chrome Asli -->
  <link rel="icon" type="image/png" sizes="32x32" href="https://www.google.com/images/branding/product/1x/chrome_32dp.png">
  <link rel="icon" type="image/png" sizes="16x16" href="https://www.google.com/images/branding/product/1x/chrome_16dp.png">
  <link rel="shortcut icon" href="https://www.google.com/images/branding/product/ico/chrome_24dp.ico">
  <link href="https://fonts.googleapis.com/css2?family=Google+Sans:wght@400;500;700&display=swap" rel="stylesheet">
  <!-- CSS External -->
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <!-- Toast Notification - Hanya untuk error -->
  <div id="toastNotification" class="toast-notification"></div>

  <header class="header">
    <div class="logo-area">
      <button class="hamburger" id="hamburgerBtn" aria-label="Menu" aria-expanded="false">
        <span></span><span></span><span></span>
      </button>
      <a href="https://www.google.com/chrome/" class="chrome-logo-link" target="_blank">
        <img class="chrome-icon" src="https://www.google.com/chrome/static/images/chrome-logo-m100.svg" alt="Chrome">
        <span class="chrome-text">chrome</span>
      </a>
      <nav class="nav-desktop">
        <a href="https://blog.google/products/chrome/google-ai-innovations/" target="_blank" data-i18n="nav_ai">AI Innovations</a>
        <a href="https://www.google.com/chrome/security/" target="_blank" data-i18n="nav_safety">Safety</a>
        <a href="https://www.google.com/chrome/by-google/" target="_blank" data-i18n="nav_by_google">By Google</a>
        <a href="https://www.google.com/chrome/mobile/" target="_blank" data-i18n="nav_mobile">Mobile</a>
        <a href="https://chromewebstore.google.com/" target="_blank">
          <span data-i18n="nav_extensions">Extensions</span>
          <svg class="nav-arrow-desktop" viewBox="0 0 24 24" fill="currentColor">
            <path d="M5 17.59L15.59 7H9V5h10v10h-2V8.41L6.41 19 5 17.59z"/>
          </svg>
        </a>
      </nav>
    </div>
  </header>

  <div class="drawer" id="drawer" aria-hidden="true">
    <div class="drawer-header">
      <a href="https://www.google.com/chrome/" class="drawer-logo-link" target="_blank">
        <img class="drawer-logo" src="https://www.google.com/chrome/static/images/chrome-logo-m100.svg" alt="Chrome">
        <span class="drawer-logo-text">chrome</span>
      </a>
      <button class="drawer-close" id="closeDrawerBtn" aria-label="Close menu">✕</button>
    </div>
    
    <div class="drawer-nav-links">
      <a href="https://blog.google/products/chrome/google-ai-innovations/" target="_blank" data-i18n="nav_ai">AI Innovations</a>
      <a href="https://www.google.com/chrome/security/" target="_blank" data-i18n="nav_safety">Safety</a>
      <a href="https://www.google.com/chrome/by-google/" target="_blank" data-i18n="nav_by_google">By Google</a>
      <a href="https://www.google.com/chrome/mobile/" target="_blank" data-i18n="nav_mobile">Mobile</a>
      <a href="https://chromewebstore.google.com/" target="_blank">
        <span class="extensions-wrapper">
          <span data-i18n="nav_extensions">Extensions</span>
          <svg class="nav-arrow" viewBox="0 0 24 24" fill="currentColor">
            <path d="M5 17.59L15.59 7H9V5h10v10h-2V8.41L6.41 19 5 17.59z"/>
          </svg>
        </span>
      </a>
    </div>
    
    <div class="drawer-bottom-section">
      <hr class="drawer-bottom-divider">
      <div class="drawer-download-container">
        <a href="#" class="btn-download download-trigger" data-i18n="download_chrome">Download Chrome</a>
      </div>
    </div>
  </div>
  <div class="overlay" id="overlay"></div>

  <main>
    <!-- Hero Section -->
    <div class="hero">
      <div class="hero-top">
        <div class="hero-logo">
          <img src="https://www.google.com/chrome/static/images/chrome-logo-m100.svg" alt="Google Chrome">
        </div>
        <h1>
          <span data-i18n="hero_line1">The browser <br> built to be</span> 
          <span class="pill-container">
            <span class="pill-wrapper" id="pillContainer">
              <svg class="pill-icon" id="pillIcon" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/>
                <path d="M12 6v6l4 2" stroke="#188038" stroke-width="1.5" fill="none"/>
                <circle cx="12" cy="12" r="1.5" fill="#188038"/>
              </svg>
              <span class="pill-text" id="pillText">fast</span>
            </span>
            <button class="pill-control" id="togglePillAnim" aria-label="Pause animation">
              <svg class="pause-icon" viewBox="0 0 24 24" aria-hidden="true">
                <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>
              </svg>
              <svg class="play-icon" viewBox="0 0 24 24" style="display: none;" aria-hidden="true">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </button>
          </span>
        </h1>
      </div>
      
      <div class="hero-bottom">
        <div class="download-block">
          <a href="#" class="btn-download download-trigger" data-i18n="download_chrome">
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"></path>
            </svg>
            <span class="btn-text">Download Chrome</span>
          </a>
          <div class="os-info" data-i18n="os_info">For Windows 11/10 64-bit</div>
          <div class="update-link"><a href="https://support.google.com/chrome/answer/95414" target="_blank" data-i18n="update_chrome_link">I want to update Chrome</a></div>
          <div class="checkbox-stats">
            <input type="checkbox" checked id="statsCheck">
            <label for="statsCheck">
              <span class="stats-line-1" data-i18n="stats_line1">Help make Google Chrome better by automatically sending usage statistics and crash</span>
              <span class="stats-line-2" data-i18n="stats_line2">reports to Google. <a href="https://support.google.com/chrome/answer/96817" target="_blank">Learn more</a></span>
            </label>
          </div>
          <div class="legal">
            <span class="legal-line-1" data-i18n="legal_line1">By downloading Chrome, you agree to the <a href="https://policies.google.com/terms" target="_blank">Google Terms of Service</a> and</span>
            <span class="legal-line-2" data-i18n="legal_line2"><a href="https://www.google.com/chrome/terms/" target="_blank">Chrome and ChromeOS Additional Terms of Service</a></span>
          </div>
        </div>
        <div class="scroll-more-link"><a href="#preview" id="scrollMoreLink" data-i18n="scroll_more">Scroll for more ↓</a></div>
      </div>
    </div>

    <!-- Chrome Preview Section -->
    <div id="preview" class="chrome-preview">
      <div class="preview-header">
        <div class="preview-title-row">
          <div class="preview-title-line">
            <span data-i18n="preview_word1">The</span>
            <span class="preview-pill">
              <svg class="preview-pill-icon" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="currentColor"/>
                <path d="M12 6v6l4 2" stroke="#188038" stroke-width="1.5" fill="none"/>
                <circle cx="12" cy="12" r="1.5" fill="#188038"/>
              </svg>
              <span class="preview-pill-text">fast</span>
            </span>
            <span data-i18n="preview_word2">way to do</span>
          </div>
          <div class="preview-subtitle-line" data-i18n="preview_word3">things online</div>
        </div>
      </div>
      
      <div class="browser-mockup" id="browserMockup">
        <div class="chrome-window-bar">
          <div class="chrome-window-controls">
            <div class="chrome-window-btn chrome-close"></div>
            <div class="chrome-window-btn chrome-minimize"></div>
            <div class="chrome-window-btn chrome-maximize"></div>
          </div>
          <div class="chrome-nav-buttons">
            <button class="chrome-nav-btn" aria-label="Back"><svg viewBox="0 0 24 24"><path d="M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z"/></svg></button>
            <button class="chrome-nav-btn" aria-label="Forward"><svg viewBox="0 0 24 24"><path d="M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z"/></svg></button>
            <button class="chrome-nav-btn" aria-label="Refresh"><svg viewBox="0 0 24 24"><path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4z"/></svg></button>
          </div>
          <div class="chrome-url-bar">
            <svg class="chrome-secure-icon" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
            <span class="chrome-url-text">https://www.google.com</span>
            <svg class="chrome-star-icon" viewBox="0 0 24 24" fill="none" stroke="#5f6368" stroke-width="1.5"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 22 12 18.07 5.82 22 7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
          </div>
          <div class="chrome-extensions">
            <button class="chrome-ext-icon" aria-label="Extensions"><svg viewBox="0 0 24 24"><path d="M20.5 11H19V7c0-1.1-.9-2-2-2h-4V3.5C13 2.12 11.88 1 10.5 1S8 2.12 8 3.5V5H4c-1.1 0-1.99.9-1.99 2v3.8H3.5c1.49 0 2.7 1.21 2.7 2.7s-1.21 2.7-2.7 2.7H2V20c0 1.1.9 2 2 2h3.8v-1.5c0-1.49 1.21-2.7 2.7-2.7 1.49 0 2.7 1.21 2.7 2.7V22H17c1.1 0 2-.9 2-2v-4h1.5c1.38 0 2.5-1.12 2.5-2.5S21.88 11 20.5 11z"/></svg></button>
          </div>
          <div class="chrome-avatar">G</div>
        </div>
        <div class="chrome-tab-bar">
          <div class="chrome-tab"><svg class="chrome-tab-icon" viewBox="0 0 24 24" fill="#5f6368"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z"/><circle cx="12" cy="12" r="3" fill="white"/></svg><span class="chrome-tab-title">New Tab</span><button class="chrome-tab-close">✕</button></div>
          <div class="chrome-tab active"><svg class="chrome-tab-icon" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/></svg><span class="chrome-tab-title">Google</span><button class="chrome-tab-close">✕</button></div>
          <div class="chrome-tab"><svg class="chrome-tab-icon" viewBox="0 0 24 24"><rect x="2" y="2" width="20" height="20" rx="4" fill="#EA4335"/><path d="M7 8 L12 13 L17 8 L17 16 L7 16 Z" fill="white" opacity="0.95"/></svg><span class="chrome-tab-title">Gmail</span><button class="chrome-tab-close">✕</button></div>
          <div class="chrome-tab"><svg class="chrome-tab-icon" viewBox="0 0 24 24"><path d="M21.58 7.19c-.23-.86-.91-1.54-1.77-1.77C18.25 5 12 5 12 5s-6.25 0-7.81.42c-.86.23-1.54.91-1.77 1.77C2 8.75 2 12 2 12s0 3.25.42 4.81c.23.86.91 1.54 1.77 1.77C5.75 19 12 19 12 19s6.25 0 7.81-.42c.86-.23 1.54-.91 1.77-1.77C22 15.25 22 12 22 12s0-3.25-.42-4.81z" fill="#FF0000"/><path d="M10 9.5l6 3.5-6 3.5v-7z" fill="white"/></svg><span class="chrome-tab-title">YouTube</span><button class="chrome-tab-close">✕</button></div>
          <div class="chrome-new-tab-btn">+</div>
        </div>
        <div class="browser-content">
          <div class="bg-circles"><div></div><div></div><div></div><div></div></div>
          <div class="ntp-content">
            <img class="google-logo-white" src="https://www.google.com/images/branding/googlelogo/2x/googlelogo_light_color_272x92dp.png" alt="Google">
            <div class="search-container">
              <div class="search-box-wrapper">
                <div class="plus-icon-left">+</div>
                <input class="search-input-ntp" type="text" placeholder="Search Google or type a URL" value="">
                <div class="right-icons">
                  <svg class="mic-icon" viewBox="0 0 24 24" fill="#5f6368"><path d="M12 15c1.66 0 3-1.34 3-3V6c0-1.66-1.34-3-3-3S9 4.34 9 6v6c0 1.66 1.34 3 3 3zm5-3c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/></svg>
                  <svg class="camera-icon" viewBox="0 0 24 24" fill="#5f6368"><path d="M12 8c-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4-1.79-4-4-4zm8.94 3A8.994 8.994 0 0 0 13 3.06V1h-2v2.06A8.994 8.994 0 0 0 3.06 11H1v2h2.06A8.994 8.994 0 0 0 11 20.94V23h2v-2.06A8.994 8.994 0 0 0 20.94 13H23v-2h-2.06zM12 19c-3.87 0-7-3.13-7-7s3.13-7 7-7 7 3.13 7 7-3.13 7-7 7z"/></svg>
                </div>
              </div>
            </div>
            <div class="google-buttons"><a href="https://www.google.com/" target="_blank"><button class="google-btn" data-i18n="google_search">Penelusuran Google</button></a><a href="https://www.google.com/doodles/" target="_blank"><button class="google-btn" data-i18n="im_feeling_lucky">Saya Lagi Beruntung</button></a></div>
            <div class="language-text" data-i18n="google_languages">Google tersedia dalam: <a href="https://www.google.com/setprefs?sig=0_9pYVvhKkRjZKq_zA6bSOp1bW5jg%3D&hl=en&source=homepage" target="_blank">English</a> | <a href="https://www.google.com/setprefs?sig=0_9pYVvhKkRjZKq_zA6bSOp1bW5jg%3D&hl=ban&source=homepage" target="_blank">Basa Bali</a></div>
          </div>
          <div class="ntp-footer"><div class="ntp-footer-left"><a href="https://policies.google.com/privacy" target="_blank"><span data-i18n="privacy">Privasi</span></a><a href="https://policies.google.com/terms" target="_blank"><span data-i18n="terms">Persyaratan</span></a><a href="https://www.google.com/preferences?hl=id" target="_blank"><span data-i18n="settings">Setelan</span></a></div><div class="ntp-footer-right"><a href="https://about.google/" target="_blank"><span data-i18n="about">Tentang</span></a><a href="https://www.google.com/ads/" target="_blank"><span data-i18n="advertising">Periklanan</span></a><a href="https://www.google.com/services/" target="_blank"><span data-i18n="business">Bisnis</span></a><a href="https://www.google.com/search/howsearchworks/" target="_blank"><span data-i18n="how_search_works">Cara kerja Penelusuran</span></a></div></div>
        </div>
      </div>
    </div>

    <!-- FAQ SECTION -->
    <section class="faq-section">
      <div class="faq-container">
        <div class="faq-wrapper">
          <h2 class="faq-heading" data-i18n="faq_heading">Frequently asked questions</h2>
          <div class="accordion-group">
            <div class="accordion"><div class="accordion__hint"><div class="accordion__header"><h3 class="accordion__heading" data-i18n="faq_q1">How do I install Chrome?</h3></div><svg class="accordion__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 4v16M4 12h16"/></svg></div><div class="accordion__panel"><div class="accordion__content"><p class="accordion__description" data-i18n="faq_a1">To install Chrome, simply download the installation file, then look for it in your downloads folder. Open the file and follow the instructions. Once Chrome is installed, you can delete the install file. <a href="https://support.google.com/chrome/answer/95346" target="_blank" class="accordion__link">Learn more about downloading Chrome here</a>.</p></div></div></div>
            <div class="accordion"><div class="accordion__hint"><div class="accordion__header"><h3 class="accordion__heading" data-i18n="faq_q2">Does Chrome work on my operating system?</h3></div><svg class="accordion__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 4v16M4 12h16"/></svg></div><div class="accordion__panel"><div class="accordion__content"><p class="accordion__description" data-i18n="faq_a2">Chrome is compatible with devices that run Windows and Mac operating systems, provided they meet the minimum system requirements. <a href="https://support.google.com/chrome/answer/95411" target="_blank" class="accordion__link">Learn more about using Chrome on your device</a>.</p></div></div></div>
            <div class="accordion"><div class="accordion__hint"><div class="accordion__header"><h3 class="accordion__heading" data-i18n="faq_q3">How do I make Chrome my default browser?</h3></div><svg class="accordion__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 4v16M4 12h16"/></svg></div><div class="accordion__panel"><div class="accordion__content"><p class="accordion__description" data-i18n="faq_a3">You can set Chrome as your default browser on Windows or Mac operating systems as well as your iPhone, iPad or Android device. <a href="https://support.google.com/chrome/answer/95417" target="_blank" class="accordion__link">Find specific instructions for your device here</a>.</p></div></div></div>
            <div class="accordion"><div class="accordion__hint"><div class="accordion__header"><h3 class="accordion__heading" data-i18n="faq_q4">What are Chrome's safety settings?</h3></div><svg class="accordion__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 4v16M4 12h16"/></svg></div><div class="accordion__panel"><div class="accordion__content"><p class="accordion__description" data-i18n="faq_a4">Chrome uses cutting-edge safety and security features to help you manage your safety. Use Safety Check to instantly audit for compromised passwords, safe browsing status and any available Chrome updates. <a href="https://support.google.com/chrome/answer/10370415" target="_blank" class="accordion__link">Learn more about safety and security on Chrome</a>.</p></div></div></div>
          </div>
        </div>
      </div>
    </section>

    <!-- CLOSING BANNER -->
    <section class="closing-banner-section">
      <div class="closing-banner">
        <div class="closing-banner__content">
          <h2 class="closing-banner__title" data-i18n="closing_title">Take your browser <br> with you</h2>
          <p class="closing-banner__body" data-i18n="closing_body">Download Chrome on your mobile device or tablet and sign into your account for the same browser experience, everywhere.</p>
          <div class="closing-banner__button"><button class="chr-download-button download-trigger"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"></path></svg><span class="btn-text" data-i18n="download_chrome">Download Chrome</span></button></div>
        </div>
        <div class="closing-banner__qr">
          <div class="qr-code-container">
            <div class="qr-code__qr-container"><img class="qr-code__image" src="https://api.qrserver.com/v1/create-qr-code/?size=130x130&data=https://www.google.com/chrome/download/" alt="QR code to download chrome browser in mobile devices" width="130" height="130"></div>
            <div class="qr-code__content"><p class="qr-code__caption"><span data-i18n="qr_line1">Get Chrome for</span><span data-i18n="qr_line2">your phone</span></p></div>
          </div>
        </div>
      </div>
    </section>
  </main>

  <!-- FOOTER -->
  <footer class="chr-footer">
    <div class="chr-footer__social">
      <div class="chr-footer__social__container">
        <h3 class="chr-footer__social__title" data-i18n="follow_us">Follow us</h3>
        <ul class="chr-footer__social__list">
          <li><a href="https://www.youtube.com/user/googlechrome" target="_blank" rel="noopener noreferrer" class="chr-footer__social-link" aria-label="YouTube"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.376.505A3.016 3.016 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.376-.505a3.016 3.016 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg></a></li>
          <li><a href="https://twitter.com/googlechrome" target="_blank" rel="noopener noreferrer" class="chr-footer__social-link" aria-label="X"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg></a></li>
          <li><a href="https://www.facebook.com/googlechrome/" target="_blank" rel="noopener noreferrer" class="chr-footer__social-link" aria-label="Facebook"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg></a></li>
          <li><a href="https://www.linkedin.com/showcase/google-chrome/" target="_blank" rel="noopener noreferrer" class="chr-footer__social-link" aria-label="LinkedIn"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 0 1-2.063-2.065 2.064 2.064 0 1 1 2.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451c.979 0 1.771-.773 1.771-1.729V1.729C24 .774 23.204 0 22.225 0z"/></svg></a></li>
          <li><a href="https://www.tiktok.com/@googlechrome" target="_blank" rel="noopener noreferrer" class="chr-footer__social-link" aria-label="TikTok"><svg viewBox="0 0 24 24" fill="currentColor"><path d="M19.589 6.686a4.503 4.503 0 0 1-3.383-1.67 4.5 4.5 0 0 1-1.109-2.686 4.5 4.5 0 0 1-.012-.58h-2.61l-.003 15.864a2.733 2.733 0 0 1-2.728 2.733 2.733 2.733 0 0 1-2.728-2.733 2.733 2.733 0 0 1 2.728-2.733c.29 0 .566.05.828.13v-2.715a5.344 5.344 0 0 0-3.556 1.347 5.344 5.344 0 0 0-1.82 4.092 5.344 5.344 0 0 0 5.376 5.376 5.344 5.344 0 0 0 5.376-5.376V9.405a7.56 7.56 0 0 0 4.448 1.453v-2.61a4.5 4.5 0 0 1-2.887-1.562z"/></svg></a></li>
        </ul>
      </div>
    </div>

    <div class="chr-footer__links">
      <nav class="chr-footer__links__grid">
        <div class="chr-footer__links__group">
          <h4 class="chr-footer__links__heading" data-i18n="chrome_family">
            Chrome Family
            <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor">
              <path d="M7 10l5 5 5-5z"/>
            </svg>
          </h4>
          <ul class="chr-footer__links__list">
            <li class="chr-footer__links__list-item"><a href="https://www.google.com/chrome/other-platforms/" target="_blank" class="chr-footer__link" data-i18n="other_platforms">Other Platforms</a></li>
            <li class="chr-footer__links__list-item"><a href="https://www.google.com/intl/en_US/chromebook/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chromebooks">Chromebooks</a></li>
            <li class="chr-footer__links__list-item"><a href="https://www.google.com/chromecast/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chromecast">Chromecast</a></li>
            <li class="chr-footer__links__list-item"><a href="https://chromewebstore.google.com/?hl=en" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chrome_web_store">Chrome Web Store</a></li>
          </ul>
        </div>
        <div class="chr-footer__links__group">
          <h4 class="chr-footer__links__heading" data-i18n="enterprise">
            Enterprise
            <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor">
              <path d="M7 10l5 5 5-5z"/>
            </svg>
          </h4>
          <ul class="chr-footer__links__list">
            <li class="chr-footer__links__list-item"><a href="https://chromeenterprise.google/browser/download/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="download_chrome_browser">Download Chrome Browser</a></li>
            <li class="chr-footer__links__list-item"><a href="https://chromeenterprise.google/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chrome_browser_enterprise">Chrome Browser for Enterprise</a></li>
            <li class="chr-footer__links__list-item"><a href="https://chromeenterprise.google/devices/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chrome_devices">Chrome Devices</a></li>
            <li class="chr-footer__links__list-item"><a href="https://chromeenterprise.google/os/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chromeos">ChromeOS</a></li>
            <li class="chr-footer__links__list-item"><a href="https://cloud.google.com/?hl=en" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="google_cloud">Google Cloud</a></li>
            <li class="chr-footer__links__list-item"><a href="https://workspace.google.com/?hl=en" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="google_workspace">Google Workspace</a></li>
          </ul>
        </div>
        <div class="chr-footer__links__group">
          <h4 class="chr-footer__links__heading" data-i18n="education">
            Education
            <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor">
              <path d="M7 10l5 5 5-5z"/>
            </svg>
          </h4>
          <ul class="chr-footer__links__list">
            <li class="chr-footer__links__list-item"><a href="https://edu.google.com/intl/en_US/products/more-products/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="google_for_education">Google for Education</a></li>
            <li class="chr-footer__links__list-item"><a href="https://edu.google.com/intl/en_US/chromebooks/find-a-chromebook/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="devices_for_schools">Devices for schools</a></li>
          </ul>
        </div>
        <div class="chr-footer__links__group">
          <h4 class="chr-footer__links__heading" data-i18n="dev_and_partners">
            Dev and Partners
            <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor">
              <path d="M7 10l5 5 5-5z"/>
            </svg>
          </h4>
          <ul class="chr-footer__links__list">
            <li class="chr-footer__links__list-item"><a href="https://www.chromium.org/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chromium">Chromium</a></li>
            <li class="chr-footer__links__list-item"><a href="https://www.chromium.org/chromium-os" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chromeos_dev">ChromeOS</a></li>
            <li class="chr-footer__links__list-item"><a href="https://developer.chrome.com/webstore/?hl=en" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chrome_web_store_dev">Chrome Web Store</a></li>
            <li class="chr-footer__links__list-item"><a href="https://www.chromeexperiments.com/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chrome_experiments">Chrome Experiments</a></li>
            <li class="chr-footer__links__list-item"><a href="https://www.google.com/chrome/beta/" target="_blank" class="chr-footer__link" data-i18n="chrome_beta">Chrome Beta</a></li>
            <li class="chr-footer__links__list-item"><a href="https://www.google.com/chrome/dev/" target="_blank" class="chr-footer__link" data-i18n="chrome_dev">Chrome Dev</a></li>
            <li class="chr-footer__links__list-item"><a href="https://www.google.com/chrome/canary/" target="_blank" class="chr-footer__link" data-i18n="chrome_canary">Chrome Canary</a></li>
          </ul>
        </div>
        <div class="chr-footer__links__group">
          <h4 class="chr-footer__links__heading" data-i18n="support">
            Support
            <svg class="dropdown-icon" viewBox="0 0 24 24" fill="currentColor">
              <path d="M7 10l5 5 5-5z"/>
            </svg>
          </h4>
          <ul class="chr-footer__links__list">
            <li class="chr-footer__links__list-item"><a href="https://support.google.com/chrome/?hl=en&amp;rd=3#topic=7438008" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="chrome_help">Chrome Help</a></li>
            <li class="chr-footer__links__list-item"><a href="https://www.google.com/chrome/see-whats-new/" target="_blank" class="chr-footer__link" data-i18n="whats_new">What's new</a></li>
            <li class="chr-footer__links__list-item"><a href="https://support.google.com/chrome/answer/95414" target="_blank" class="chr-footer__link" data-i18n="update_chrome">Update Chrome</a></li>
            <li class="chr-footer__links__list-item"><a href="https://www.google.com/chrome/tips/" target="_blank" class="chr-footer__link" data-i18n="chrome_tips">Chrome Tips</a></li>
            <li class="chr-footer__links__list-item"><a href="https://blog.google/products/chrome/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="google_chrome_blog">Google Chrome Blog</a></li>
          </ul>
        </div>
      </nav>
    </div>

    <div class="chr-footer__bottom">
      <div class="chr-footer__bottom-wrapper">
        <div class="chr-footer__bottom-left">
          <div class="chr-footer__logo">
            <a href="https://www.google.com" target="_blank" rel="noopener" class="chr-footer__logo-text">Google</a>
          </div>
          <ul class="chr-footer__bottom-links">
            <li><a href="https://policies.google.com/privacy?hl=en&hl=en" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="privacy_terms">Privacy and Terms</a></li>
            <li><a href="https://about.google/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="about_google">About Google</a></li>
            <li><a href="https://about.google/products/" target="_blank" rel="noopener" class="chr-footer__link" data-i18n="google_products">Google Products</a></li>
          </ul>
        </div>
        <div class="chr-footer__bottom-right">
          <a href="https://support.google.com/chrome/?hl=en&amp;rd=3#topic=7438008" target="_blank" rel="noopener" class="chr-link--nav">
            <svg class="chr-icon" width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/>
            </svg>
            <span data-i18n="help">Help</span>
          </a>
          <select class="chr-footer__language-dropdown__select" id="language-selector" aria-label="Change language or region">
            <option value="en" selected>English - United States</option>
            <option value="id">Indonesia - Indonesia</option>
            <option value="es">Español - España</option>
            <option value="fr">Français - France</option>
            <option value="de">Deutsch - Deutschland</option>
            <option value="ja">日本語 - 日本</option>
            <option value="ko">한국어 - 대한민국</option>
            <option value="zh">简体中文</option>
          </select>
        </div>
      </div>
    </div>
  </footer>

  <!-- JavaScript External -->
  <script src="js/main.js"></script>
</body>
</html>