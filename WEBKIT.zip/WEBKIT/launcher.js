#!/usr/bin/env node

const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const os = require('os');

// ==================== KONFIGURASI ====================
const CONFIG = {
    port: {
        default: 3000,
        min: 1024,
        max: 65535
    }
};

// ==================== WARNA ====================
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    dim: '\x1b[2m',
    green: '\x1b[32m',
    red: '\x1b[31m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m'
};

// ==================== CEK PHP ====================
function isPhpInstalled() {
    try {
        execSync('php -v', { stdio: 'ignore', timeout: 5000 });
        return true;
    } catch {
        return false;
    }
}

// ==================== BANNER ====================
function showBanner() {
    console.clear();
    
    console.log(`${colors.green}${colors.bright}`);
    console.log(`    ╔═══════════════════════════════════════════════════════════════════╗`);
    console.log(`    ║                                                                   ║`);
    console.log(`    ║   ██╗    ██╗███████╗██████╗     ██╗  ██╗██╗████████╗              ║`);
    console.log(`    ║   ██║    ██║██╔════╝██╔══██╗    ██║ ██╔╝██║╚══██╔══╝              ║`);
    console.log(`    ║   ██║ █╗ ██║█████╗  ██████╔╝    █████╔╝ ██║   ██║                 ║`);
    console.log(`    ║   ██║███╗██║██╔══╝  ██╔══██╗    ██╔═██╗ ██║   ██║                 ║`);
    console.log(`    ║   ╚███╔███╔╝███████╗██████╔╝    ██║  ██╗██║   ██║                 ║`);
    console.log(`    ║    ╚══╝╚══╝ ╚══════╝╚═════╝     ╚═╝  ╚═╝╚═╝   ╚═╝                 ║`);
    console.log(`    ║                                                                   ║`);
    console.log(`    ║                         🔥 WEBKIT v2.0 🔥                          ║`);
    console.log(`    ║                      "Website Toolkit"                            ║`);
    console.log(`    ║                                                                   ║`);
    console.log(`    ╚═══════════════════════════════════════════════════════════════════╝`);
    console.log(`${colors.reset}`);
    
    console.log(` ${colors.dim}┌─────────────────────────────────────────────────────────────────────┐${colors.reset}`);
    console.log(` ${colors.dim}│${colors.reset}  ${colors.green}●${colors.reset} STATUS: ${colors.green}READY${colors.reset}                                    ${colors.dim}│${colors.reset}`);
    console.log(` ${colors.dim}└─────────────────────────────────────────────────────────────────────┘${colors.reset}\n`);
}

// ==================== UTILITY ====================
function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function isValidPort(port) {
    return !isNaN(port) && port >= CONFIG.port.min && port <= CONFIG.port.max;
}

// ==================== SIMPLE SPINNER ====================
async function withSpinner(message, fn) {
    const spinChars = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];
    let i = 0;
    const interval = setInterval(() => {
        process.stdout.write(`\r ${colors.cyan}${spinChars[i]}${colors.reset} ${message}`);
        i = (i + 1) % spinChars.length;
    }, 80);
    
    try {
        const result = await fn();
        clearInterval(interval);
        process.stdout.write(`\r ${colors.green}✓${colors.reset} ${message}\n`);
        return result;
    } catch (error) {
        clearInterval(interval);
        process.stdout.write(`\r ${colors.red}✗${colors.reset} ${message}\n`);
        throw error;
    }
}

// ==================== PROJECT SCANNER ====================
function scanProjects() {
    const projectsDir = path.join(__dirname, 'projects');
    const projects = [];
    
    try {
        if (!fs.existsSync(projectsDir)) {
            console.log(`\n ${colors.yellow}⚠ Folder 'projects' tidak ditemukan!${colors.reset}`);
            console.log(` ${colors.cyan}💡 Buat folder 'projects' dan masukkan project Anda di dalamnya${colors.reset}\n`);
            return projects;
        }
        
        const items = fs.readdirSync(projectsDir, { withFileTypes: true });
        
        for (const item of items) {
            if (!item.isDirectory()) continue;
            
            const projectPath = path.join(projectsDir, item.name);
            const indexPath = path.join(projectPath, 'index.html');
            
            let hasIndex = false;
            try {
                hasIndex = fs.existsSync(indexPath) && fs.statSync(indexPath).isFile();
            } catch (err) {
                continue;
            }
            
            projects.push({
                name: item.name,
                path: projectPath,
                hasIndex: hasIndex
            });
        }
        
        projects.sort((a, b) => a.name.localeCompare(b.name));
        
    } catch (err) {
        console.log(` ${colors.red}✗ Error: ${err.message}${colors.reset}`);
    }
    
    return projects;
}

// ==================== MENU SELECT ====================
async function showMenu(projects) {
    return new Promise((resolve) => {
        console.log(` ${colors.dim}┌─────────────────────────────────────────────────────────────────────┐${colors.reset}`);
        console.log(` ${colors.dim}│${colors.reset}  ${colors.green}📁 SELECT (${projects.length})${colors.reset}                                                    ${colors.dim}│${colors.reset}`);
        console.log(` ${colors.dim}├─────────────────────────────────────────────────────────────────────┤${colors.reset}`);
        
        if (projects.length === 0) {
            console.log(` ${colors.dim}│${colors.reset}  ${colors.yellow}⚠ Tidak ada project ditemukan${colors.reset}                                        ${colors.dim}│${colors.reset}`);
            console.log(` ${colors.dim}│${colors.reset}  ${colors.yellow}💡 Buat folder di dalam 'projects' dengan file index.html${colors.reset}                   ${colors.dim}│${colors.reset}`);
        } else {
            for (let i = 0; i < projects.length; i++) {
                const project = projects[i];
                const statusIcon = project.hasIndex ? `${colors.green}✓${colors.reset}` : `${colors.red}✗${colors.reset}`;
                const statusText = project.hasIndex ? `${colors.green}READY${colors.reset}` : `${colors.red}NO INDEX${colors.reset}`;
                const number = `${i + 1}`.padStart(2, ' ');
                
                let displayName = project.name.length > 35 ? project.name.substring(0, 32) + '...' : project.name;
                console.log(` ${colors.dim}│${colors.reset}  ${colors.cyan}[${number}]${colors.reset} ${statusIcon} ${colors.bright}${displayName}${colors.reset} ${colors.dim}(${statusText})${colors.reset}`);
            }
        }
        
        console.log(` ${colors.dim}├─────────────────────────────────────────────────────────────────────┤${colors.reset}`);
        console.log(` ${colors.dim}│${colors.reset}  ${colors.yellow}[R]${colors.reset} ${colors.dim}↻${colors.reset} Refresh          ${colors.red}[Q]${colors.reset} ${colors.dim}✗${colors.reset} Exit                          ${colors.dim}│${colors.reset}`);
        console.log(` ${colors.dim}└─────────────────────────────────────────────────────────────────────┘${colors.reset}\n`);
        
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        
        rl.question(` ${colors.green}┌─[${colors.cyan}web${colors.green}@${colors.yellow}kit${colors.green}]${colors.reset}\n ${colors.green}└──╼ ${colors.white}$ ${colors.reset}`, (answer) => {
            rl.close();
            
            const input = answer.toLowerCase().trim();
            
            if (input === 'q' || input === 'exit' || input === 'quit') {
                resolve('exit');
            } else if (input === 'r' || input === 'refresh') {
                resolve('refresh');
            } else {
                const choice = parseInt(input) - 1;
                if (!isNaN(choice) && choice >= 0 && choice < projects.length) {
                    resolve(projects[choice]);
                } else {
                    resolve('invalid');
                }
            }
        });
    });
}

// ==================== PORT INPUT ====================
async function askPort(defaultPort = CONFIG.port.default) {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
    
    return new Promise((resolve) => {
        console.log(`\n ${colors.dim}┌─────────────────────────────────────────────────────────────────────┐${colors.reset}`);
        console.log(` ${colors.dim}│${colors.reset}  ${colors.yellow}🔌 PORT CONFIGURATION${colors.reset}                                           ${colors.dim}│${colors.reset}`);
        console.log(` ${colors.dim}│${colors.reset}  ${colors.dim}Default port: ${colors.cyan}${defaultPort}${colors.reset} (Enter untuk default)                     ${colors.dim}│${colors.reset}`);
        console.log(` ${colors.dim}└─────────────────────────────────────────────────────────────────────┘${colors.reset}\n`);
        
        rl.question(` ${colors.green}┌─[${colors.cyan}set-port${colors.green}@${colors.yellow}kit${colors.green}]${colors.reset}\n ${colors.green}└──╼ ${colors.white}$ ${colors.reset}`, (answer) => {
            rl.close();
            
            const input = answer.trim();
            if (input === '') {
                resolve(defaultPort);
                return;
            }
            
            const port = parseInt(input);
            if (isValidPort(port)) {
                resolve(port);
            } else {
                console.log(`\n ${colors.red}✗ Port invalid! Gunakan ${CONFIG.port.min}-${CONFIG.port.max}${colors.reset}`);
                console.log(` ${colors.green}✓ Menggunakan port default: ${defaultPort}${colors.reset}\n`);
                resolve(defaultPort);
            }
        });
    });
}

// ==================== RUN SERVER ====================
async function runServer(project) {
    if (!project || !project.hasIndex) {
        console.log(`\n ${colors.red}╔══════════════════════════════════════════════════════════════════════╗${colors.reset}`);
        console.log(` ${colors.red}║${colors.reset}  ${colors.red}✗ ERROR: Project tidak memiliki index.html!${colors.reset}                         ${colors.red}║${colors.reset}`);
        console.log(` ${colors.red}╚══════════════════════════════════════════════════════════════════════╝${colors.reset}\n`);
        return false;
    }
    
    const port = await askPort(CONFIG.port.default);
    
    console.log(`\n ${colors.green}╔══════════════════════════════════════════════════════════════════════╗${colors.reset}`);
    console.log(` ${colors.green}║${colors.reset}  ${colors.green}🚀 LAUNCHING PROJECT${colors.reset}                                              ${colors.green}║${colors.reset}`);
    console.log(` ${colors.green}╟──────────────────────────────────────────────────────────────────────╢${colors.reset}`);
    
    let projectName = project.name.length > 50 ? project.name.substring(0, 47) + '...' : project.name;
    console.log(` ${colors.green}║${colors.reset}  ${colors.cyan}📦 Name:${colors.reset} ${colors.bright}${projectName}${colors.reset}                                                  ${colors.green}║${colors.reset}`);
    console.log(` ${colors.green}║${colors.reset}  ${colors.cyan}🔌 Port:${colors.reset} ${colors.yellow}${port}${colors.reset}                                                       ${colors.green}║${colors.reset}`);
    console.log(` ${colors.green}║${colors.reset}  ${colors.cyan}🌐 Localhost:${colors.reset} ${colors.green}http://localhost:${port}${colors.reset}                                       ${colors.green}║${colors.reset}`);
    console.log(` ${colors.green}║${colors.reset}  ${colors.cyan}🌐 127.0.0.1:${colors.reset} ${colors.green}http://127.0.0.1:${port}${colors.reset}                                         ${colors.green}║${colors.reset}`);
    
    // Get local network IP
    try {
        const networkInterfaces = os.networkInterfaces();
        for (const name of Object.keys(networkInterfaces)) {
            for (const net of networkInterfaces[name]) {
                if (net.family === 'IPv4' && !net.internal) {
                    console.log(` ${colors.green}║${colors.reset}  ${colors.cyan}🌍 Network:${colors.reset} ${colors.green}http://${net.address}:${port}${colors.reset}${' '.repeat(45 - net.address.length)}${colors.green}║${colors.reset}`);
                    break;
                }
            }
        }
    } catch (err) {
        // Skip IP network display if error
    }
    
    console.log(` ${colors.green}║${colors.reset}                                                                      ${colors.green}║${colors.reset}`);
    console.log(` ${colors.green}║${colors.reset}  ${colors.yellow}⚠  Tekan ${colors.bright}Ctrl+C${colors.reset}${colors.yellow} untuk menghentikan server${colors.reset}                               ${colors.green}║${colors.reset}`);
    console.log(` ${colors.green}╚══════════════════════════════════════════════════════════════════════╝${colors.reset}\n`);
    
    return new Promise((resolve) => {
        let serverProcess = null;
        
        try {
            const args = ['-S', `127.0.0.1:${port}`, '-t', project.path];
            serverProcess = spawn('php', args, {
                stdio: 'inherit',
                shell: true,
                env: { ...process.env }
            });
            
            let isResolved = false;
            
            serverProcess.on('close', (code) => {
                if (!isResolved) {
                    isResolved = true;
                    if (code !== 0 && code !== null && code !== 130) {
                        console.log(`\n ${colors.red}✗ Server berhenti dengan kode: ${code}${colors.reset}`);
                    } else {
                        console.log(`\n ${colors.yellow}⚠ Server dihentikan${colors.reset}`);
                    }
                    resolve();
                }
            });
            
            serverProcess.on('error', (err) => {
                if (!isResolved) {
                    isResolved = true;
                    console.log(`\n ${colors.red}✗ Error: ${err.message}${colors.reset}`);
                    resolve();
                }
            });
            
        } catch (err) {
            console.log(`\n ${colors.red}✗ Gagal menjalankan server: ${err.message}${colors.reset}`);
            resolve(false);
        }
    });
}

// ==================== MAIN FUNCTION ====================
async function main() {
    showBanner();
    
    // Cek PHP
    if (!isPhpInstalled()) {
        console.log(` ${colors.red}╔══════════════════════════════════════════════════════════════════════╗${colors.reset}`);
        console.log(` ${colors.red}║${colors.reset}  ${colors.red}✗ PHP TIDAK DITEMUKAN!${colors.reset}                                              ${colors.red}║${colors.reset}`);
        console.log(` ${colors.red}║${colors.reset}                                                                      ${colors.red}║${colors.reset}`);
        console.log(` ${colors.red}║${colors.reset}  ${colors.yellow}WEBKIT membutuhkan PHP untuk menjalankan server.${colors.reset}                         ${colors.red}║${colors.reset}`);
        console.log(` ${colors.red}║${colors.reset}                                                                      ${colors.red}║${colors.reset}`);
        console.log(` ${colors.red}║${colors.reset}  ${colors.cyan}💡 Install PHP:${colors.reset}                                                      ${colors.red}║${colors.reset}`);
        console.log(` ${colors.red}║${colors.reset}     Windows: choco install php${colors.reset}                                           ${colors.red}║${colors.reset}`);
        console.log(` ${colors.red}║${colors.reset}     Mac: brew install php${colors.reset}                                                   ${colors.red}║${colors.reset}`);
        console.log(` ${colors.red}║${colors.reset}     Linux: sudo apt install php${colors.reset}                                              ${colors.red}║${colors.reset}`);
        console.log(` ${colors.red}╚══════════════════════════════════════════════════════════════════════╝${colors.reset}\n`);
        process.exit(1);
    }
    
    console.log(` ${colors.green}[✓]${colors.reset} PHP ${colors.green}terdeteksi${colors.reset}\n`);
    
    let isRunning = true;
    
    while (isRunning) {
        let projects = [];
        try {
            projects = await withSpinner('Memindai project...', async () => {
                return scanProjects();
            });
        } catch (err) {
            console.log(` ${colors.yellow}⚠ Error: ${err.message}${colors.reset}`);
            await sleep(1000);
            continue;
        }
        
        const result = await showMenu(projects);
        
        if (result === 'exit') {
            console.log(`\n ${colors.magenta}╔══════════════════════════════════════════════════════════════════════╗${colors.reset}`);
            console.log(` ${colors.magenta}║${colors.reset}  ${colors.magenta}👋 EXIT${colors.reset} - Terima kasih telah menggunakan WEBKIT!                 ${colors.magenta}║${colors.reset}`);
            console.log(` ${colors.magenta}║${colors.reset}  ${colors.dim}➜ Happy coding!${colors.reset}                                                    ${colors.magenta}║${colors.reset}`);
            console.log(` ${colors.magenta}╚══════════════════════════════════════════════════════════════════════╝${colors.reset}\n`);
            isRunning = false;
            process.exit(0);
        }
        
        if (result === 'refresh') {
            continue;
        }
        
        if (result === 'invalid') {
            console.log(`\n ${colors.red}✗ Pilihan tidak valid!${colors.reset}`);
            await sleep(1000);
            continue;
        }
        
        if (result && typeof result === 'object') {
            await runServer(result);
            console.log(`\n ${colors.cyan}[*]${colors.reset} Kembali ke menu utama...\n`);
            await sleep(1500);
        }
    }
}

// ==================== START APPLICATION ====================
main().catch((err) => {
    console.error(`\n ${colors.red}[!] Fatal Error:${colors.reset} ${err.message}`);
    process.exit(1);
});