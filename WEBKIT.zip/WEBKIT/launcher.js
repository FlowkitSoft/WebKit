#!/usr/bin/env node

const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const readline = require('readline');
const os = require('os');

const CONFIG = { port: { default: 3000, min: 1024, max: 65535 } };

const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    green: '\x1b[32m',
    red: '\x1b[31m',
    yellow: '\x1b[33m',
    cyan: '\x1b[36m',
    white: '\x1b[37m',
    dim: '\x1b[2m'
};

function isPhpInstalled() {
    try { execSync('php -v', { stdio: 'ignore', timeout: 5000 }); return true; } 
    catch { return false; }
}

function showBanner() {
    console.clear();
    console.log(`${colors.green}${colors.bright}`);
    console.log(`    =====================================================`);
    console.log(`            ██╗    ██╗███████╗██████╗ ██╗  ██╗██╗████████╗`);
    console.log(`            ██║    ██║██╔════╝██╔══██╗██║ ██╔╝██║╚══██╔══╝`);
    console.log(`            ██║ █╗ ██║█████╗  ██████╔╝█████╔╝ ██║   ██║   `);
    console.log(`            ██║███╗██║██╔══╝  ██╔══██╗██╔═██╗ ██║   ██║   `);
    console.log(`            ╚███╔███╔╝███████╗██████╔╝██║  ██╗██║   ██║   `);
    console.log(`             ╚══╝╚══╝ ╚══════╝╚═════╝ ╚═╝  ╚═╝╚═╝   ╚═╝   `);
    console.log(`    =====================================================`);
    console.log(`              Website Toolkit - Multi Project Launcher`);
    console.log(`                     Version 1.0 - 2024`);
    console.log(`    =====================================================${colors.reset}\n`);
}

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function isValidPort(port) { return !isNaN(port) && port >= 1024 && port <= 65535; }

async function withSpinner(message, fn) {
    const spinChars = ['|', '/', '-', '\\'];
    let i = 0;
    const interval = setInterval(() => {
        process.stdout.write(`\r ${colors.green}[*]${colors.reset} ${message} ${spinChars[i]}`);
        i = (i + 1) % spinChars.length;
    }, 100);
    try {
        const result = await fn();
        clearInterval(interval);
        process.stdout.write(`\r ${colors.green}[+]${colors.reset} ${message} done.          \n`);
        return result;
    } catch (error) {
        clearInterval(interval);
        process.stdout.write(`\r ${colors.red}[-]${colors.reset} ${message} failed.          \n`);
        throw error;
    }
}

function scanProjects() {
    const projectsDir = path.join(__dirname, 'projects');
    const projects = [];
    try {
        if (!fs.existsSync(projectsDir)) {
            console.log(` ${colors.yellow}[!]${colors.reset} Folder 'projects' not found. Create it and add your projects.\n`);
            return projects;
        }
        const items = fs.readdirSync(projectsDir, { withFileTypes: true });
        for (const item of items) {
            if (!item.isDirectory()) continue;
            const projectPath = path.join(projectsDir, item.name);
            const indexPath = path.join(projectPath, 'index.html');
            let hasIndex = false;
            try { hasIndex = fs.existsSync(indexPath) && fs.statSync(indexPath).isFile(); } 
            catch (err) { continue; }
            projects.push({ name: item.name, path: projectPath, hasIndex: hasIndex });
        }
        projects.sort((a, b) => a.name.localeCompare(b.name));
    } catch (err) { console.log(` ${colors.red}[-]${colors.reset} Error: ${err.message}`); }
    return projects;
}

async function showMenu(projects) {
    return new Promise((resolve) => {
        console.log(` ${colors.green}[*]${colors.reset} Available projects:\n`);
        if (projects.length === 0) {
            console.log(`     ${colors.yellow}[!]${colors.reset} No projects found.`);
            console.log(`     ${colors.green}[*]${colors.reset} Create folder inside 'projects' with index.html\n`);
        } else {
            for (let i = 0; i < projects.length; i++) {
                const status = projects[i].hasIndex ? `${colors.green}[READY]${colors.reset}` : `${colors.red}[NO INDEX]${colors.reset}`;
                console.log(`        ${colors.cyan}${i + 1}.${colors.reset} ${projects[i].name} ${status}`);
            }
            console.log('');
        }
        console.log(` ${colors.green}[*]${colors.reset} Commands: ${colors.cyan}<number>${colors.reset} select  ${colors.cyan}r${colors.reset} refresh  ${colors.cyan}q${colors.reset} quit\n`);
        
        const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
        rl.question(` ${colors.green}webkit >${colors.reset} `, (answer) => {
            rl.close();
            const input = answer.toLowerCase().trim();
            if (input === 'q') resolve('exit');
            else if (input === 'r') resolve('refresh');
            else {
                const choice = parseInt(input) - 1;
                if (!isNaN(choice) && choice >= 0 && choice < projects.length) resolve(projects[choice]);
                else resolve('invalid');
            }
        });
    });
}

async function askPort(defaultPort = 3000) {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    return new Promise((resolve) => {
        console.log(` ${colors.green}[*]${colors.reset} Port configuration (default: ${colors.cyan}${defaultPort}${colors.reset})`);
        rl.question(` ${colors.green}webkit >${colors.reset} `, (answer) => {
            rl.close();
            const input = answer.trim();
            if (input === '') resolve(defaultPort);
            else {
                const port = parseInt(input);
                if (isValidPort(port)) resolve(port);
                else { console.log(` ${colors.red}[-]${colors.reset} Invalid port. Using ${defaultPort}.\n`); resolve(defaultPort); }
            }
        });
    });
}

async function runServer(project) {
    if (!project || !project.hasIndex) {
        console.log(` ${colors.red}[-]${colors.reset} Project without index.html.\n`);
        return false;
    }
    
    const port = await askPort(3000);
    
    console.log(`\n ${colors.green}[+]${colors.reset} Launching ${project.name} on port ${port}`);
    console.log(` ${colors.green}[+]${colors.reset} Local:   http://localhost:${port}`);
    console.log(` ${colors.green}[+]${colors.reset} Loopback: http://127.0.0.1:${port}`);
    
    try {
        const nets = os.networkInterfaces();
        for (const name of Object.keys(nets)) {
            for (const net of nets[name]) {
                if (net.family === 'IPv4' && !net.internal) {
                    console.log(` ${colors.green}[+]${colors.reset} Network:  http://${net.address}:${port}`);
                    break;
                }
            }
        }
    } catch (err) {}
    
    console.log(` ${colors.yellow}[!]${colors.reset} Press Ctrl+C to stop the server\n`);
    
    return new Promise((resolve) => {
        let serverProcess = null;
        let isResolved = false;
        
        // Handler untuk Ctrl+C - hanya stop server, bukan exit
        const sigintHandler = () => {
            if (!isResolved) {
                console.log(`\n ${colors.yellow}[!]${colors.reset} Stopping server...`);
                if (serverProcess && !serverProcess.killed) {
                    serverProcess.kill('SIGINT');
                }
            }
        };
        
        // Pasang handler sementara
        process.on('SIGINT', sigintHandler);
        
        try {
            const args = ['-S', `127.0.0.1:${port}`, '-t', project.path];
            serverProcess = spawn('php', args, {
                stdio: 'inherit'
            });
            
            serverProcess.on('close', (code) => {
                if (!isResolved) {
                    isResolved = true;
                    process.removeListener('SIGINT', sigintHandler);
                    if (code !== 0 && code !== null && code !== 130) {
                        console.log(` ${colors.red}[-]${colors.reset} Server stopped with code: ${code}`);
                    } else {
                        console.log(` ${colors.yellow}[!]${colors.reset} Server stopped`);
                    }
                    resolve();
                }
            });
            
            serverProcess.on('error', (err) => {
                if (!isResolved) {
                    isResolved = true;
                    process.removeListener('SIGINT', sigintHandler);
                    console.log(` ${colors.red}[-]${colors.reset} Error: ${err.message}`);
                    resolve();
                }
            });
            
        } catch (err) {
            isResolved = true;
            process.removeListener('SIGINT', sigintHandler);
            console.log(` ${colors.red}[-]${colors.reset} Failed: ${err.message}`);
            resolve(false);
        }
    });
}

async function main() {
    showBanner();
    
    if (!isPhpInstalled()) {
        console.log(` ${colors.red}[-]${colors.reset} PHP not found!\n`);
        console.log(` ${colors.green}[*]${colors.reset} Install PHP:`);
        console.log(`     Windows: choco install php`);
        console.log(`     Mac: brew install php`);
        console.log(`     Linux: sudo apt install php\n`);
        process.exit(1);
    }
    
    const phpVersion = execSync('php -v').toString().split('\n')[0];
    console.log(` ${colors.green}[+]${colors.reset} PHP detected: ${phpVersion}\n`);
    
    let isRunning = true;
    
    while (isRunning) {
        let projects = [];
        try {
            projects = await withSpinner('Scanning projects', async () => scanProjects());
        } catch (err) {
            await sleep(1000);
            continue;
        }
        
        const result = await showMenu(projects);
        
        if (result === 'exit') {
            console.log(`\n ${colors.green}[+]${colors.reset} Goodbye!\n`);
            isRunning = false;
            process.exit(0);
        } else if (result === 'refresh') {
            continue;
        } else if (result === 'invalid') {
            console.log(` ${colors.red}[-]${colors.reset} Invalid choice\n`);
            await sleep(1000);
            continue;
        } else if (result && typeof result === 'object') {
            await runServer(result);
            console.log(`\n ${colors.green}[*]${colors.reset} Returning to menu...\n`);
            await sleep(1500);
        }
    }
}

main().catch((err) => {
    console.error(` ${colors.red}[-]${colors.reset} Fatal: ${err.message}`);
    process.exit(1);
});